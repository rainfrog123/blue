// ==UserScript==
// @name         read aloud stop
// @description  Press Alt+M to click the "Stop" (voice) button on ChatGPT
// @namespace    gp-voice-stop
// @version      1.0.0
// @match        https://chat.openai.com/*
// @match        https://chatgpt.com/*
// @match        https://www.chatgpt.com/*
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  /** Utilities **/
  const isEditable = (el) => {
    if (!el) return false;
    const tag = el.tagName?.toLowerCase();
    if (tag === 'input' || tag === 'textarea') return true;
    if (el.isContentEditable) return true;
    return false;
  };

  // Try to find the Stop button by multiple robust cues
  function findStopButton() {
    // Primary: aria-label="Stop" + data-testid
    let btn = document.querySelector(
      'button[aria-label="Stop"][data-testid="voice-play-turn-action-button"]'
    );
    if (btn) return btn;

    // Fallback: same testid, inner SVG is a square (stop icon), and visible
    const candidates = Array.from(
      document.querySelectorAll('button[data-testid="voice-play-turn-action-button"]')
    ).filter((b) => b.offsetParent !== null); // visible-ish
    for (const b of candidates) {
      const aria = (b.getAttribute('aria-label') || '').toLowerCase();
      if (aria.includes('stop')) return b;
      // Extra fallback: look for a <path> with a square-ish stop icon (fill-rule present in your snippet)
      const hasSquarePath = !!b.querySelector('svg path[fill-rule][clip-rule]');
      if (hasSquarePath) return b;
    }
    return null;
  }

  function clickStop() {
    const btn = findStopButton();
    if (btn) {
      btn.click();
      // Optional visual flash to confirm
      btn.animate([{ outline: '2px solid #ff4d4f' }, { outline: 'none' }], {
        duration: 250,
      });
      return true;
    }
    return false;
  }

  // Debounce repeated key repeats
  let lastPress = 0;
  const MIN_INTERVAL_MS = 150;

  window.addEventListener(
    'keydown',
    (e) => {
      // Alt+M (case-insensitive)
      if (!e.altKey || e.key.toLowerCase() !== 'm') return;

      // Avoid triggering while typing in fields/editors
      if (isEditable(document.activeElement)) return;

      const now = performance.now();
      if (now - lastPress < MIN_INTERVAL_MS) return;
      lastPress = now;

      const clicked = clickStop();
      if (clicked) {
        e.preventDefault();
        e.stopPropagation();
      }
    },
    { capture: true }
  );

  // Optional: expose a command in the console
  // window.__voiceStop = clickStop;
})();
